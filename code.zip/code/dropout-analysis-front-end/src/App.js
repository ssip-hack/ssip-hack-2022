import React, { useEffect } from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { Navbar, Footer, Sidebar } from "./components";
import {
  AgeWiseAnalytics,
  CasteWiseAnalytics,
  GenderWiseAnalysis,
  DistrictWiseAnalytics,
  SchoolWiseAnalytics,
  CompareMajorCities,
} from "./pages";
import "./App.css";

import { useStateContext } from "./contexts/ContextProvider";
import HomePage from "./pages/HomePage";
import PreviousYearTrendsPage from "./pages/PreviousYearTrendsPage";

const App = () => {
  const { setCurrentColor, setCurrentMode, currentMode, activeMenu } =
    useStateContext();

  useEffect(() => {
    const currentThemeColor = localStorage.getItem("colorMode");
    const currentThemeMode = localStorage.getItem("themeMode");
    if (currentThemeColor && currentThemeMode) {
      setCurrentColor(currentThemeColor);
      setCurrentMode(currentThemeMode);
    }
  }, []);

  return (
    <div className={currentMode === "Dark" ? "dark" : ""}>
      <BrowserRouter>
        <div className="flex relative dark:bg-main-dark-bg">
          {activeMenu ? (
            <div className="w-72 fixed sidebar dark:bg-secondary-dark-bg bg-white ">
              <Sidebar />
            </div>
          ) : (
            <div className="w-0 dark:bg-secondary-dark-bg">
              <Sidebar />
            </div>
          )}
          <div
            className={
              activeMenu
                ? "dark:bg-main-dark-bg  bg-main-bg min-h-screen md:ml-72 w-full  "
                : "bg-main-bg dark:bg-main-dark-bg  w-full min-h-screen flex-2 "
            }
          >
            <div className="fixed md:static bg-main-bg dark:bg-main-dark-bg navbar w-full ">
              <Navbar />
            </div>
            <div>
              <Routes>
                {/* dashboard  */}
                <Route path="/" element={<HomePage />} />

                <Route path="/Home" element={<HomePage />} />
                <Route
                  path="/age-wise-analytics"
                  element={<AgeWiseAnalytics />}
                />
                <Route
                  path="/caste-wise-analytics"
                  element={<CasteWiseAnalytics />}
                />
                <Route
                  path="/gender-wise-analytics"
                  element={<GenderWiseAnalysis />}
                />
                <Route
                  path="/district-wise-analytics"
                  element={<DistrictWiseAnalytics />}
                />
                <Route
                  path="/school-wise-analytics"
                  element={<SchoolWiseAnalytics />}
                />
                <Route
                  path="/compare-major-cities"
                  element={<CompareMajorCities />}
                />
                <Route
                  path="/previous-year-trends"
                  element={<PreviousYearTrendsPage />}
                />
                {/* apps  */}
              </Routes>
            </div>
            <Footer />
          </div>
        </div>
      </BrowserRouter>
    </div>
  );
};

export default App;
