import React, { useState, useEffect } from "react";
import axios from "axios";
import {
  ChartComponent,
  SeriesCollectionDirective,
  SeriesDirective,
  Inject,
  Legend,
  Category,
  Tooltip,
  DataLabel,
  BarSeries,
} from "@syncfusion/ej2-react-charts";

const DistrictWiseAnalyticsComponent = (sampleData) => {
  var data = sampleData["sampleData"];
  return (
    <div>
      <h1 className="text-2xl text-center">District Wise Analytics</h1>
      <hr className="mt-3" />
      {/* create bar series chart in syncfusion */}
      <ChartComponent
        id="charts"
        primaryXAxis={{
          valueType: "Category",
          interval: 1,
          majorGridLines: { width: 1 },
          font: { fontWeight: "600", color: "#000000" },
        }}
        primaryYAxis={{
          labelFormat: "{value}%",
          edgeLabelPlacement: "Shift",
          majorGridLines: { width: 0 },
          lineStyle: { width: 0 },
        }}
        chartArea={{ border: { width: 0 } }}
        tooltip={{ enable: true }}
        width={window.innerWidth < 768 ? "100%" : "80%"}
        height="700"
        legendSettings={{ visible: true }}
      >
        <Inject services={[BarSeries, Legend, Tooltip, Category, DataLabel]} />
        <SeriesCollectionDirective>
          <SeriesDirective
            dataSource={data}
            xName="name"
            yName="value"
            name="X AXIS - Dropouts"
            type="Bar"
          />
        </SeriesCollectionDirective>
      </ChartComponent>
    </div>
  );
};

export default DistrictWiseAnalyticsComponent;
