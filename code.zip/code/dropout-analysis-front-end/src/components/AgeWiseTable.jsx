import React from "react";

const AgeWiseTable = (data) => {
  console.log(data);
  return (
    <div className="flex items-center justify-center m-4">
      <table
        border={1}
        className="text-center w-full text-sm text-gray-500 dark:text-gray-400"
      >
        <thead className="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
          <tr>
            <th>Age Group</th>
            <th>Dropout Rates</th>
          </tr>
        </thead>
        {data.map((item, index) => (
          <tr
            key={index}
            className="bg-white border-b dark:bg-gray-800 dark:border-gray-700"
          >
            <td>{item.label}</td>
            <td>{item.dropout}</td>
          </tr>
        ))}
      </table>
    </div>
  );
};

export default AgeWiseTable;
