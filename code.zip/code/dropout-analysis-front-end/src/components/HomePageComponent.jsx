import React from "react";
const HomePageComponent = () => {
  return (
    <div>
      <h1 className="text-2xl text-center">Dropout Analysis Dashboard</h1>
      <hr className="mt-3" />
      <div className="container m-5">
        <div className="container mx-auto bg-white m-5 rounded p-5">
          <h1>Alert</h1>

          <br />
          <span>
            <img
              src={require("../assets/new-flashing.gif")}
              style={{ display: "inline" }}
            />{" "}
            {"    "}
            Narmada district has higher dropout rates.{" "}
            <a
              href="/district-wise-analytics"
              className="text-violet-500 hover:text-violet-900"
            >
              Check out the detailed analytics.
            </a>
          </span>
          <br />
          <span>
            <img
              src={require("../assets/new-flashing.gif")}
              style={{ display: "inline" }}
            />{" "}
            {"    "}SC category has higher dropout rates.{" "}
            <a
              href="/caste-wise-analytics"
              className="text-violet-500 hover:text-violet-900"
            >
              Check out the detailed analytics.
            </a>
          </span>
          <br />
          <span>
            <img
              src={require("../assets/new-flashing.gif")}
              style={{ display: "inline" }}
            />{" "}
            {"    "}8 to 10 year age group has higher dropout rates.{" "}
            <a
              href="/age-wise-analytics"
              className="text-violet-500 hover:text-violet-900"
            >
              Check out the detailed analytics.
            </a>
          </span>
          <br />
          <span>
            <img
              src={require("../assets/new-flashing.gif")}
              style={{ display: "inline" }}
            />{" "}
            {"    "}
            2021 dropout rates are increased.{" "}
            <a
              href="/previous-year-trends"
              className="text-violet-500 hover:text-violet-900"
            >
              Check out the detailed analytics.
            </a>
          </span>
          <br />
          <span>
            <img
              src={require("../assets/new-flashing.gif")}
              style={{ display: "inline" }}
            />{" "}
            {"    "}
            Government Schools has higher dropout rates.{" "}
            <a
              href="/school-wise-analytics"
              className="text-violet-500 hover:text-violet-900"
            >
              Check out the detailed analytics.
            </a>
          </span>
          <br />
          <span>
            <img
              src={require("../assets/new-flashing.gif")}
              style={{ display: "inline" }}
            />{" "}
            {"    "}
            Female gender has higher dropout rates.{" "}
            <a
              href="/gender-wise-analytics"
              className="text-violet-500 hover:text-violet-900"
            >
              Check out the detailed analytics.
            </a>
          </span>
        </div>
      </div>
    </div>
  );
};

export default HomePageComponent;
