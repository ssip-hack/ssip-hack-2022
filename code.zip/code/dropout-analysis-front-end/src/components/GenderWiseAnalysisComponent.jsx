import React, { useState, useEffect } from "react";
import {
  AccumulationChartComponent,
  AccumulationDataLabel,
  AccumulationLegend,
  AccumulationSeriesCollectionDirective,
  AccumulationSeriesDirective,
  AccumulationTooltip,
  Inject,
  PieSeries,
} from "@syncfusion/ej2-react-charts";
import axios from "axios";
import { getData } from "@syncfusion/ej2/spreadsheet";
const CasteWiseAnalyticsComponent = (sampleData) => {
  var data = sampleData["sampleData"];

  // pie chart to show the caste wise distribution
  return (
    <div>
      <div className="flex flex-wrap justify-center">
        <div className="w-5/6 bg-white dark:text-gray-200 dark:bg-secondary-dark-bg rounded-2xl p-6 m-3">
          <div className="flex flex-col">
            <AccumulationChartComponent
              legendSettings={{ position: "Bottom" }}
              tooltip={{ enable: "true" }}
            >
              <Inject
                services={[
                  PieSeries,
                  AccumulationDataLabel,
                  AccumulationLegend,
                  AccumulationTooltip,
                ]}
              ></Inject>
              <AccumulationSeriesCollectionDirective>
                <AccumulationSeriesDirective
                  type="Pie"
                  dataSource={data}
                  xName="name"
                  yName="value"
                  dataLabel={{
                    visible: true,
                    position: "Inside",
                    name: "value",
                  }}
                ></AccumulationSeriesDirective>
              </AccumulationSeriesCollectionDirective>
            </AccumulationChartComponent>
            <hr />
          </div>
        </div>
      </div>
    </div>
  );
};

export default CasteWiseAnalyticsComponent;
