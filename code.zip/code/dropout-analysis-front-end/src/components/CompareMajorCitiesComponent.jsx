import React, { useEffect } from "react";
import AgeWiseTable from "./AgeWiseTable";
import {
  ChartComponent,
  Inject,
  LineSeries,
  Category,
  Legend,
  Tooltip,
  SeriesDirective,
  SeriesCollectionDirective,
  DataLabel,
  SplineAreaSeries,
  DateTime,
} from "@syncfusion/ej2-react-charts";
import { useState } from "react";

const areaChartData = [
  [
    { x: new Date(2012, 0, 1), y: 11 },
    { x: new Date(2013, 0, 1), y: 12 },
    { x: new Date(2014, 0, 1), y: 10 },
    { x: new Date(2015, 0, 1), y: 13 },
    { x: new Date(2016, 0, 1), y: 23 },
    { x: new Date(2017, 0, 1), y: 25 },
    { x: new Date(2018, 0, 1), y: 29 },
    { x: new Date(2019, 0, 1), y: 15 },
    { x: new Date(2020, 0, 1), y: 38 },
    { x: new Date(2021, 0, 1), y: 12 },
  ],
  [
    { x: new Date(2012, 0, 1), y: 14 },
    { x: new Date(2013, 0, 1), y: 12 },
    { x: new Date(2014, 0, 1), y: 13 },
    { x: new Date(2015, 0, 1), y: 21 },
    { x: new Date(2016, 0, 1), y: 23 },
    { x: new Date(2017, 0, 1), y: 17 },
    { x: new Date(2018, 0, 1), y: 15 },
    { x: new Date(2019, 0, 1), y: 28 },
    { x: new Date(2020, 0, 1), y: 35 },
    { x: new Date(2021, 0, 1), y: 23 },
  ],
  [
    { x: new Date(2012, 0, 1), y: 16 },
    { x: new Date(2013, 0, 1), y: 19 },
    { x: new Date(2014, 0, 1), y: 21 },
    { x: new Date(2015, 0, 1), y: 36 },
    { x: new Date(2016, 0, 1), y: 25 },
    { x: new Date(2017, 0, 1), y: 27 },
    { x: new Date(2018, 0, 1), y: 23 },
    { x: new Date(2019, 0, 1), y: 27 },
    { x: new Date(2020, 0, 1), y: 31 },
    { x: new Date(2021, 0, 1), y: 33 },
  ],
  [
    { x: new Date(2012, 0, 1), y: 29 },
    { x: new Date(2013, 0, 1), y: 29 },
    { x: new Date(2014, 0, 1), y: 24 },
    { x: new Date(2015, 0, 1), y: 38 },
    { x: new Date(2016, 0, 1), y: 39 },
    { x: new Date(2017, 0, 1), y: 32 },
    { x: new Date(2018, 0, 1), y: 21 },
    { x: new Date(2019, 0, 1), y: 28 },
    { x: new Date(2020, 0, 1), y: 41 },
    { x: new Date(2021, 0, 1), y: 24 },
  ],
  [
    { x: new Date(2012, 0, 1), y: 38 },
    { x: new Date(2013, 0, 1), y: 23 },
    { x: new Date(2014, 0, 1), y: 41 },
    { x: new Date(2015, 0, 1), y: 36 },
    { x: new Date(2016, 0, 1), y: 25 },
    { x: new Date(2017, 0, 1), y: 27 },
    { x: new Date(2018, 0, 1), y: 23 },
    { x: new Date(2019, 0, 1), y: 27 },
    { x: new Date(2020, 0, 1), y: 44 },
    { x: new Date(2021, 0, 1), y: 23 },
  ],
];

const areaCustomSeries = [
  {
    dataSource: areaChartData[0],
    xName: "x",
    yName: "y",
    name: "Ahmedabad",
    opacity: "0.5",
    type: "SplineArea",
    width: "2",
  },
  {
    dataSource: areaChartData[1],
    xName: "x",
    yName: "y",
    name: "Gandhinagar",
    opacity: "0.5",
    type: "SplineArea",
    width: "2",
  },
  {
    dataSource: areaChartData[2],
    xName: "x",
    yName: "y",
    name: "Vadodara",
    opacity: "0.5",
    type: "SplineArea",
    width: "2",
  },
  {
    dataSource: areaChartData[3],
    xName: "x",
    yName: "y",
    name: "Rajkot",
    opacity: "0.5",
    type: "SplineArea",
    width: "2",
  },
  {
    dataSource: areaChartData[4],
    xName: "x",
    yName: "y",
    name: "Bhavnagar",
    opacity: "0.5",
    type: "SplineArea",
    width: "2",
  },
];

const AgeWiseAnalyticsComponent = () => {
  return (
    <div className="mt-3">
      <br />
      <div className="w-full">
        <ChartComponent
          id="charts"
          primaryXAxis={{
            valueType: "DateTime",
            labelFormat: "y",
            majorGridLines: { width: 0 },
            intervalType: "Years",
            edgeLabelPlacement: "Shift",
            labelStyle: { color: "gray" },
          }}
          primaryYAxis={{
            labelFormat: "{value}%",
            lineStyle: { width: 0 },
            maximum: 50,
            interval: 10,
            majorTickLines: { width: 0 },
            minorTickLines: { width: 0 },
            labelStyle: { color: "gray" },
          }}
          chartArea={{ border: { width: 0 } }}
          legendSettings={{ background: "white" }}
        >
          <Inject services={[SplineAreaSeries, DateTime, Legend]} />
          <SeriesCollectionDirective>
            {/* eslint-disable-next-line react/jsx-props-no-spreading */}
            {areaCustomSeries.map((item, index) => (
              <SeriesDirective key={index} {...item} />
            ))}
          </SeriesCollectionDirective>
        </ChartComponent>
      </div>
    </div>
  );
};

export default AgeWiseAnalyticsComponent;
