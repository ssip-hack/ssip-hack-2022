import React, { useEffect } from "react";
import {
  ChartComponent,
  Inject,
  LineSeries,
  Category,
  Legend,
  Tooltip,
  SeriesDirective,
  SeriesCollectionDirective,
  DataLabel,
} from "@syncfusion/ej2-react-charts";
const sampleData = [
  { label: "2013-14", dropout: 8.26 },
  { label: "2014-15", dropout: 17.28 },
  { label: "2015-16", dropout: 15.84 },
  { label: "2016-17", dropout: 15.97 },
  { label: "2017-18", dropout: 12.61 },
  { label: "2018-19", dropout: 12.83 },
  { label: "2019-20", dropout: 16.63 },
  { label: "2020-21", dropout: 18.82 },
];

const PreviousYearTrends = () => {
  return (
    <div>
      <h1 className="text-2xl text-center">Previous Year Trends</h1>
      <hr className="mt-3" />
      <ChartComponent
        legendSettings={{ visible: true }}
        primaryXAxis={{ valueType: "Category", title: "Previous Year Trends" }}
        primaryYAxis={{ title: "Year Wise Dropout rates" }}
        tooltip={{ enable: "true" }}
      >
        <Inject
          services={[LineSeries, Category, Legend, Tooltip, DataLabel]}
        ></Inject>
        <SeriesCollectionDirective>
          <SeriesDirective
            type="Line"
            dataSource={sampleData}
            xName="label"
            yName="dropout"
            name="dropout"
            marker={{ visible: true, dataLabel: { visible: true } }}
          ></SeriesDirective>
        </SeriesCollectionDirective>
      </ChartComponent>
    </div>
  );
};

export default PreviousYearTrends;
