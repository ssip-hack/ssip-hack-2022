import React, { useEffect } from "react";
import {
  ChartComponent,
  Inject,
  LineSeries,
  Category,
  Legend,
  Tooltip,
  SeriesDirective,
  SeriesCollectionDirective,
  DataLabel,
} from "@syncfusion/ej2-react-charts";

const AgeWiseAnalyticsComponent = (sampleData) => {
  var data = sampleData["sampleData"];
  return (
    <div>
      <h1 className="text-2xl text-center">Age Wise Analytics</h1>
      <hr className="mt-3" />
      <ChartComponent
        legendSettings={{ visible: true }}
        primaryXAxis={{ valueType: "Category", title: "Age groups" }}
        primaryYAxis={{ title: "Dropout rates" }}
        tooltip={{ enable: "true" }}
      >
        <Inject
          services={[LineSeries, Category, Legend, Tooltip, DataLabel]}
        ></Inject>
        <SeriesCollectionDirective>
          <SeriesDirective
            type="Line"
            dataSource={data}
            xName="name"
            yName="value"
            name="value"
            marker={{ visible: true, dataLabel: { visible: true } }}
          ></SeriesDirective>
        </SeriesCollectionDirective>
      </ChartComponent>
    </div>
  );
};

export default AgeWiseAnalyticsComponent;
