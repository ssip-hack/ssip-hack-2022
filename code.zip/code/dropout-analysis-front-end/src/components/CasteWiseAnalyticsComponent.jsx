import React from "react";
import {
  AccumulationChartComponent,
  AccumulationDataLabel,
  AccumulationLegend,
  AccumulationSeriesCollectionDirective,
  AccumulationSeriesDirective,
  AccumulationTooltip,
  Inject,
  PieSeries,
} from "@syncfusion/ej2-react-charts";
const CasteWiseAnalyticsComponent = (sampleData, sampleDistData) => {
  console.log(sampleData);
  // const sampleData = [
  //   { name: "SC", value: 23 },
  //   { name: "ST", value: 17 },
  //   { name: "OBC", value: 17 },
  //   { name: "General", value: 13 },
  //   { name: "Others", value: 30 },
  // ];
  var data = sampleData["sampleData"];

  // pie chart to show the caste wise distribution
  return (
    <div>
      <h1 className="text-2xl text-center">Caste Wise Analytics</h1>
      <hr className="mt-3" />
      <div className="flex flex-wrap justify-center">
        <div className="w-5/6 bg-white dark:text-gray-200 dark:bg-secondary-dark-bg rounded-2xl p-6 m-3">
          <div className="flex flex-col">
            <AccumulationChartComponent
              legendSettings={{ position: "Bottom" }}
              tooltip={{ enable: "true" }}
            >
              <Inject
                services={[
                  PieSeries,
                  AccumulationDataLabel,
                  AccumulationLegend,
                  AccumulationTooltip,
                ]}
              ></Inject>
              <AccumulationSeriesCollectionDirective>
                <AccumulationSeriesDirective
                  type="Pie"
                  dataSource={data}
                  xName="name"
                  yName="value"
                  dataLabel={{
                    visible: true,
                    position: "Inside",
                    name: "value",
                  }}
                ></AccumulationSeriesDirective>
              </AccumulationSeriesCollectionDirective>
            </AccumulationChartComponent>
            <hr />
            {/* <CasteWiseTable data={sampleData} /> */}
          </div>
        </div>
      </div>
    </div>
  );
};

export default CasteWiseAnalyticsComponent;
