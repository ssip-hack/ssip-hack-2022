import React from "react";
import { HomePageComponent } from "../components";

const HomePage = () => {
  return (
    <div>
      <HomePageComponent />
    </div>
  );
};

export default HomePage;
