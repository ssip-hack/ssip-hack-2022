import React, { useState, useEffect } from "react";
import axios from "axios";
import { GenderWiseAnalysisComponent } from "../components";
const GenderWiseAnalysis = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function getData() {
      await axios
        .get("http://localhost:5001/api/gender")
        .then((res) => {
          setData(res.data);
        })
        .finally(() => {
          setLoading(false);
        });
    }
    getData();
  }, []);
  return (
    <div>
      {loading ? (
        <h1>loading</h1>
      ) : (
        <GenderWiseAnalysisComponent sampleData={data} />
      )}
    </div>
  );
};

export default GenderWiseAnalysis;
