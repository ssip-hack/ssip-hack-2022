import React, { useEffect, useState } from "react";
import axios from "axios";
import { DistrictWiseAnalyticsComponent } from "../components";
const DistrictWiseAnalytics = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function getData() {
      await axios
        .get("http://localhost:5001/api/district")
        .then((res) => {
          setData(res.data);
        })
        .finally(() => {
          setLoading(false);
        });
    }
    getData();
  }, []);
  return (
    <div>
      {loading ? (
        <h1>loading</h1>
      ) : (
        <DistrictWiseAnalyticsComponent sampleData={data} />
      )}
    </div>
  );
};

export default DistrictWiseAnalytics;
