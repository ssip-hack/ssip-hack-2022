import React, { useState, useEffect } from "react";
import { CasteWiseAnalyticsComponent } from "../components";
import axios from "axios";
const CasteWiseAnalytics = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function getData() {
      await axios
        .get("http://localhost:5001/api/social_category")
        .then((res) => {
          setData(res.data);
        })
        .finally(() => {
          setLoading(false);
        });
    }
    getData();
  }, []);
  return (
    <div>
      {loading ? (
        <h1>loading</h1>
      ) : (
        <CasteWiseAnalyticsComponent sampleData={data} />
      )}
    </div>
  );
};

export default CasteWiseAnalytics;
