import React, { useState, useEffect } from "react";
import AgeWiseAnalyticsComponent from "../components/AgeWiseAnalyticsComponent";
import axios from "axios";

const AgeWiseAnalytics = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  useEffect(() => {
    async function getData() {
      await axios
        .get("http://localhost:5001/api/age_group")
        .then((res) => {
          console.log(res.data);
          setData(res.data);
        })
        .finally(() => {
          setLoading(false);
        });
    }
    getData();
  }, []);
  console.log("Data from the javascript page");
  console.log(data);
  return (
    <div>
      {loading ? (
        <h1>loading</h1>
      ) : (
        <AgeWiseAnalyticsComponent sampleData={data} />
      )}
    </div>
  );
};

export default AgeWiseAnalytics;
