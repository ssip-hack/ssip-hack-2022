export { default as AgeWiseAnalytics } from "./AgeWiseAnalytics";
export { default as CasteWiseAnalytics } from "./CasteWiseAnalytics";
export { default as GenderWiseAnalysis } from "./GenderWiseAnalysis";
export { default as DistrictWiseAnalytics } from "./DistrictWiseAnalytics";
export { default as SchoolWiseAnalytics } from "./SchoolWiseAnalytics";
export { default as CompareMajorCities } from "./CompareMajorCities";
export { default as HomePaeg } from "./HomePage";
