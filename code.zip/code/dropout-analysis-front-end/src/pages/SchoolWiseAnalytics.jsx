import React, { useEffect, useState } from "react";
import { SchoolWiseAnalyticsComponent } from "../components";
import axios from "axios";
const SchoolWiseAnalytics = () => {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function getData() {
      await axios
        .get("http://localhost:5001/api/school_number")
        .then((res) => {
          setData(res.data);
        })
        .finally(() => {
          setLoading(false);
        });
    }
    getData();
  }, []);
  return (
    <div>
      {loading ? (
        <h1>loading</h1>
      ) : (
        <SchoolWiseAnalyticsComponent sampleData={data} />
      )}
    </div>
  );
};

export default SchoolWiseAnalytics;
