import React from "react";
import { PreviousYearTrends } from "../components";
const PreviousYearTrendsPage = () => {
  return (
    <div>
      <PreviousYearTrends />
    </div>
  );
};

export default PreviousYearTrendsPage;
