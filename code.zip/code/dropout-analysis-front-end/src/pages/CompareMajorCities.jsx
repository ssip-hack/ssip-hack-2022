import React from "react";
import { CompareMajorCitiesComponent } from "../components";

const CompareMajorCities = () => {
  return (
    <div>
      <CompareMajorCitiesComponent />
    </div>
  );
};

export default CompareMajorCities;
