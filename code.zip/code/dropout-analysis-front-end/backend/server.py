# create minimal flask app
from flask import Flask, request, jsonify, render_template
import datetime
app = Flask(__name__)

# allow cors
from flask_cors import CORS
CORS(app)

# mysql connect
import mysql.connector

mydb = mysql.connector.connect(
    host="localhost",
    user="root",
    passwd="Dhruv1563@",
    database="ssip"
)

# create a route for the app
@app.route('/')
def hello_world():
    print(mydb)
    return '''<a href="/form">FORM</a>'''

# create form for login
@app.route('/form', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        first_name = request.form['first_name']
        father_name = request.form['father_name']
        last_name = request.form['last_name']
        dob = request.form['dob']
        age_group = request.form.get('age_group')
        gender = request.form['gender']
        orphan = request.form['orphan']
        aadhar_number = request.form['aadhar_number']
        contact_number = request.form['contact_number']
        email = request.form['email']
        district = request.form.get('district')
        mother_tongue = request.form['mother_tongue']
        cwsn = request.form['cwsn']
        nationality = request.form['nationality']
        no_of_siblings = request.form['no_of_siblings']
        drug_addiction = request.form['drug_addiction']
        fathers_name = request.form['fathers_name']
        mothers_name = request.form['mothers_name']
        guardians_name = request.form['guardians_name']
        parents_contact_no = request.form['parent_contact_no']
        parents_aadhar_no = request.form['parent_aadhar_no']
        f_occupation = request.form['f_occupation']
        m_occupation = request.form['m_occupation']
        f_qualification = request.form.get('f_qualification')
        m_qualification = request.form.get('m_qualification')
        annual_income = request.form.get('annual_income')
        debt = request.form['debt']
        bpl = request.form['bpl']
        ews = request.form['ews']
        social_category = request.form.get('social_category')
        minority = request.form['minority']
        school_number = request.form['school_number']
        admission_number = request.form['admission_number']
        admission_date = request.form['admission_date']
        academic_stream = request.form.get('academic_stream')
        status_in_previous_year = request.form.get('status_in_previous_year')
        grade_in_previous_year = request.form.get('grade_in_previous_year')
        prev_year_result_type = request.form.get('prev_year_result_type')
        out_of_school = request.form['out_of_school']
        appeared_in_prev_year_exam = request.form['appeared_in_prev_year_exam']
        scholarship_holder = request.form['scholarship_holder']
        suspension_days = request.form['suspension_days']
        dropped = request.form['dropped']
        # insert into table students
        mycursor = mydb.cursor()
        sql = "INSERT INTO students VALUES ('{}','{}','{}','{}',{},{}, {},{},{},'{}',{},'{}',{},'{}',{},{},'{}','{}','{}',{},{},{},{},{},{},{},{},{},{}, {},{},{},{},'{}',{},{},{},{},{},{},{},{},{});".format(first_name, father_name, last_name, dob, gender, orphan,age_group, aadhar_number, contact_number, email,district, mother_tongue, cwsn, nationality, no_of_siblings, drug_addiction, fathers_name, mothers_name, guardians_name, parents_contact_no, parents_aadhar_no, f_occupation, m_occupation, f_qualification, m_qualification, annual_income, debt, bpl, ews, social_category, minority, school_number, admission_number, admission_date, academic_stream, status_in_previous_year, grade_in_previous_year, prev_year_result_type, out_of_school, appeared_in_prev_year_exam, scholarship_holder, suspension_days, dropped)
        print(sql)
        # iinsert into the table
        mycursor.execute(sql)
        mydb.commit()
        # return ([first_name, father_name, last_name, dob, gender, orphan, aadhar_number, contact_number, email,district, mother_tongue, cwsn, nationality, no_of_siblings, drug_addiction, fathers_name, mothers_name, guardians_name, parents_contact_no, parents_aadhar_no, f_occupation, m_occupation, f_qualification, m_qualification, annual_income, debt, bpl, ews, social_category, minority, school_number, admission_number, admission_date, academic_stream, status_in_previous_year, grade_in_previous_year, prev_year_result_type, out_of_school, appeared_in_prev_year_exam, scholarship_holder, suspension_days, dropped])
        return render_template('success.html')
    return render_template('form.html')

# # create an api route for getting data from the database
# @app.route('/api', methods=['GET'])
# def api():
#     mycursor = mydb.cursor()

#     mycursor.execute('''SELECT count(*) from students''')
#     result = mycursor.fetchall()
#     total = result[0][0] # total number of students

#     mycursor.execute('''SELECT count(*) from students WHERE dropped=1''')
#     result = mycursor.fetchall()
#     total_dropped = result[0][0] # total number of students

#     mycursor.execute('''SELECT age_group, count(*) 
#         FROM students
#         WHERE dropped=1
#         GROUP BY age_group;''')
#     json = []
#     myresult = mycursor.fetchall()
#     json.append({"age_group": []})
#     for result in myresult:
#         json[0]["age_group"].append({"name": result[0], "value": round((result[1]/total)*100, 2)})

#     mycursor.execute('''SELECT district, count(*)
#         FROM students
#         WHERE dropped=1
#         GROUP BY district;''')
#     myresult = mycursor.fetchall()
#     json.append({"district": []})
#     for result in myresult:
#         json[1]["district"].append({"name": result[0], "value": round((result[1]/total)*100, 2)})
    
#     mycursor.execute('''SELECT school_number, count(*) 
#         FROM students
#         WHERE dropped=1
#         GROUP BY school_number;''')
#     myresult = mycursor.fetchall()
#     json.append({"school_number": []})
#     for result in myresult:
#         json[2]["school_number"].append({"name": result[0], "value": round((result[1]/total)*100, 2)})
    
#     mycursor.execute('''SELECT social_category, count(*) 
#         FROM students
#         WHERE dropped=1
#         GROUP BY social_category;
#         ''')
#     myresult = mycursor.fetchall()
#     json.append({"social_category": []})
#     for result in myresult:
#         json[3]["social_category"].append({"name": result[0], "value": round((result[1]/total)*100, 2)})
#     json.append({"social_category_distribution": []})
#     for result in myresult:
#         json[4]["social_category_distribution"].append({"name": result[0], "value": int((result[1]/total_dropped)*100)})

#     mycursor.execute('''SELECT gender, count(*) 
#         FROM students
#         WHERE dropped=1
#         GROUP BY gender;
#                 ''')
#     myresult = mycursor.fetchall()
#     json.append({"gender": []})
#     for result in myresult:
#         json[5]["gender"].append({"name": result[0], "value": round((result[1]/total)*100, 2)})
#     json.append({"gender_distribution": []})
#     for result in myresult:
#         json[6]["gender_distribution"].append({"name": result[0], "value": int((result[1]/total_dropped)*100)})
#     return jsonify(json)

mycursor = mydb.cursor()
mycursor.execute('''SELECT count(*) from students;''')
result = mycursor.fetchone()
total = result[0] # total number of students
mycursor.execute('''SELECT count(*) from students WHERE dropped=1;''')
result = mycursor.fetchall()
total_dropped = result[0][0] # total number of students

@app.route('/api/age_group', methods=['GET'])
def age_group():
    mycursor = mydb.cursor()
    mycursor.execute('''SELECT age_group, count(*) 
        FROM students
        WHERE dropped=1
        GROUP BY age_group
        ORDER BY age_group;''')
    json = []
    dict = {0: '3 to 6 years', 1: '6 to 8 years', 2: '8 to 11 years', 3: '11 to 14 years', 4:'14 to 18 years'}
    myresult = mycursor.fetchall()
    for result in myresult:
        json.append({"name": dict[result[0]], "value": round((result[1]/total)*100, 2)})
    return jsonify(json)

@app.route('/api/district', methods=['GET'])
def district():
    mycursor = mydb.cursor()
    mycursor.execute('''SELECT district, count(*)
        FROM students
        WHERE dropped=1
        GROUP BY district;''')
    json = []
    dict = { 1 : "Ahmedabad", 2 : "Amreli", 3 : "Anand", 4 : "Aravalli", 5 : "Banaskantha", 6 : "Bharuch", 7 : "Bhavnagar", 8 : "Botad", 9 : "Chhota Udaipur", 10 : "Dahod", 11 : "Dang", 12 : "Devbhoomi Dwarka", 13 : "Gandhinagar", 14 : "Gir Somnath", 15 : "Jamnagar", 16 : "Junagadh", 17 : "Kheda", 18 : "Kutch", 19 : "Mahisagar", 20 : "Mehsana", 21 : "Morbi", 22 : "Narmada", 23 : "Navsari", 24 : "Panchmahal", 25 : "Patan", 26 : "Porbandar", 27 : "Rajkot", 28 : "Sabarkantha", 29 : "Surat", 30 : "Surendranagar", 31 : "Tapi", 32 : "Vadodara", 33 : "Valsad"}
    myresult = mycursor.fetchall()
    for result in myresult:
        json.append({"name": dict[int(result[0])], "value": round((result[1]/total)*100, 2)})
    return jsonify(json)

@app.route('/api/school_number', methods=['GET'])
def school_number():
    mycursor = mydb.cursor()
    mycursor.execute('''SELECT school_number, count(*) 
        FROM students
        WHERE dropped=1
        GROUP BY school_number;''')
    json = []
    myresult = mycursor.fetchall()
    print(myresult)
    for result in myresult:
        json.append({"name": result[0], "value": round((result[1]/total)*100, 2)})
    return jsonify(json)

# create the api route for gender
@app.route('/api/gender', methods=['GET'])
def gender():
    mycursor = mydb.cursor()
    mycursor.execute('''SELECT gender, count(*) 
        FROM students
        WHERE dropped=1
        GROUP BY gender;''')
    json = []
    dict = {0: "male", 1: "female"}
    myresult = mycursor.fetchall()
    for result in myresult:
        json.append({"name": dict[result[0]], "value": round((result[1]/total)*100, 2)})
    return jsonify(json)

@app.route('/api/social_category', methods=['GET'])
def social_category():
    mycursor = mydb.cursor()
    mycursor.execute('''SELECT social_category, count(*) 
        FROM students
        WHERE dropped=1
        GROUP BY social_category''')
    json = []
    dict = { 1 : "SC", 2: "ST", 3: "OBC", 4: "General",5: "Others"}
    myresult = mycursor.fetchall()
    for result in myresult:
        json.append({"name": dict[result[0]], "value": round((result[1]/total)*100, 2)})
    return jsonify(json)



# run the app
if __name__ == '__main__':
    app.run(debug=True, port=5001)
