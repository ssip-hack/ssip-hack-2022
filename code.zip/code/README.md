# README

To run the front_end use following command

```bash
cd dropout-analysis-front-end
npm install
npm start
```

To run the backend use following command

```bash
cd backend
source venv/bin/activate
python3 server.py
```

---

The front end dashboard is on the [Front End](http://localhost:3000)

The input form is on the [Form Page](http://localhost:5001/form)

---

Machine learning models are on the location `backend/ml`.
